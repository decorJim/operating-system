/*
 * Init Lab - q1.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
    #include <stdio.h>
    #include <unistd.h>
// -------------------------------------------------

/*
 * Vous devez imprimer le message indiqué dans l'énoncé:
 * - En exécutant un premier appel à printf AVANT l'appel à write
 * - Sans utiliser la fonction fflush
 * - En terminant chaque ligne par le caractère '\n' de fin de ligne
 */
void question1() {
    // TODO
   printf("09c0cf9f6191bca6b576ae56ed6de988 (printed using printf)");
   write(1, "09c0cf9f6191bca6b576ae56ed6de988 (printed using write)\n",55);
   printf("\n");
   
   

   


}
